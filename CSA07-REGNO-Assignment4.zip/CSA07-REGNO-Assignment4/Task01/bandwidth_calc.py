"""Task 1 - bandwidth per computer: legacy bus/hub vs switched star vs Wi-Fi 6."""
USERS = 30
FILE_MB = 20                      # month-end file size assumed
FILE_MBIT = FILE_MB * 8

def t(mbps):                      # seconds to save the file at this rate
    return FILE_MBIT / mbps

print("ASSUMPTIONS: 30 PCs, 10 Mbps shared coax+hub (one collision domain),")
print("CSMA/CD usable throughput ~ 40% of 10 Mbps under heavy load, 20 MB file.\n")

raw = 10 / USERS
real = 10 * 0.40 / USERS
print(f"BEFORE (bus + hub)    : raw share {raw:.2f} Mbps, realistic {real:.2f} Mbps per PC")
print(f"   time to save {FILE_MB} MB at realistic rate = {t(real):.0f} s ({t(real)/60:.1f} min)")

print("\nAFTER (switched star, full duplex):")
print("   each PC has a dedicated 1000 Mbps port (100 Mbps if Fast Ethernet)")
for srv in (1000, 10000):
    worst = srv / USERS
    print(f"   server link {srv:>5} Mbps -> worst case (all 30 save at once) {worst:7.1f} Mbps each, "
          f"{FILE_MB} MB in {t(min(worst,1000)):.1f} s")
print(f"   single user alone: {t(1000):.2f} s for {FILE_MB} MB")

phy = 1201                        # 2x2, 80 MHz, 802.11ax PHY rate (Mbps)
eff = 0.5                         # MAC efficiency + half duplex
ap = phy * eff
print(f"\nALTERNATIVE (one Wi-Fi 6 AP, 2x2 80 MHz): PHY {phy} Mbps, usable ~{ap:.0f} Mbps (half duplex)")
print(f"   per user with 30 sharing: {ap/USERS:.1f} Mbps; {FILE_MB} MB in {t(ap/USERS):.1f} s")
print(f"   worst-case ratio switched-star / Wi-Fi per user = {(1000/USERS)/(ap/USERS):.1f}x (server-limited)")
