Put your screenshots here (ping tests, show commands, topology).
