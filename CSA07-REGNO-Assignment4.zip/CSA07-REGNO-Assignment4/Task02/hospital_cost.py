"""Task 2.1-2.3 + alternative: hospital cost and failure analysis (5 blocks)."""
from itertools import combinations
from collections import deque

PORT, RUN = 18_000, 60_000
# A = Administration (houses the data centre / patient-record servers)
BLOCKS = ["A", "E", "O", "T", "L"]   # Admin+DC, Emergency, Outpatient, Theatres, Lab
CRITICAL = ["E", "T"]
SERVER = "A"

TOPOS = {
 "Bus  (E-O-A-L-T)":  [("E","O"),("O","A"),("A","L"),("L","T")],
 "Ring (A-E-T-O-L)":  [("A","E"),("E","T"),("T","O"),("O","L"),("L","A")],
 "Star (centre A)":   [("A","E"),("A","O"),("A","T"),("A","L")],
 "Full mesh":         list(combinations(BLOCKS, 2)),
 "HYBRID (triangle A-E-T + O,L spurs)": [("A","E"),("A","T"),("E","T"),("A","O"),("A","L")],
}

def reach(edges, cut):
    adj = {b: [] for b in BLOCKS}
    for a, b in edges:
        if (a, b) in cut or (b, a) in cut: continue
        adj[a].append(b); adj[b].append(a)
    seen, q = {SERVER}, deque([SERVER])
    while q:
        u = q.popleft()
        for v in adj[u]:
            if v not in seen: seen.add(v); q.append(v)
    return seen

def critical_ok(edges, cut):
    s = reach(edges, cut)
    return all(c in s for c in CRITICAL)

print(f"{'Topology':<38}{'links':>6}{'ports':>6}{'cost (Rs)':>12}")
for name, e in TOPOS.items():
    cost = len(e) * RUN + 2 * len(e) * PORT
    print(f"{name:<38}{len(e):>6}{2*len(e):>6}{cost:>12,}")

print("\nSingle cuts that disconnect Emergency or Theatres from servers:")
for name, e in TOPOS.items():
    bad = [f"{a}-{b}" for (a, b) in e if not critical_ok(e, {(a, b)})]
    print(f"  {name:<38}{', '.join(bad) if bad else 'NONE (survives every single cut)'}")

print("\nDouble cuts survived by E and T (critical rule):")
for name in ("Ring (A-E-T-O-L)", "HYBRID (triangle A-E-T + O,L spurs)", "Full mesh"):
    e = TOPOS[name]
    pairs = list(combinations(e, 2))
    ok = sum(critical_ok(e, set(p)) for p in pairs)
    print(f"  {name:<38}{ok}/{len(pairs)} double cuts survived")
print("\nMinimum links for 5 blocks with E and T 2-connected to servers = 5 (a tree has 4 and any cut breaks it).")
