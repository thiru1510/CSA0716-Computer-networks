"""Task 3.3 - Bill of Materials for the outpatient block (assumed counts, edit to your plan)."""
import csv, math
SPARE = 1.10
# (room type, count of rooms, drops per room, average run length m)
runs = [("Consulting rooms", 12, 2, 57.5),   # 35-80 m, average 57.5
        ("Waiting-hall APs", 8, 1, 60)]
# Pharmacy (96 m) is NOT copper: served by fibre to a small PoE switch in the pharmacy
copper_m = sum(c * d * l for _, c, d, l in runs)
drops = sum(c * d for _, c, d, _ in runs)
copper_total = math.ceil(copper_m * SPARE)
fibre_pharmacy = math.ceil(96 * SPARE)
fibre_main = math.ceil(420 * SPARE)
pharm_drops = 6
total_ports = drops + pharm_drops + 12   # + uplinks/spare

rows = [
 ("Layer-3 PoE+ access switch 48-port (telecom room)", 1, "units", "32 drops + uplinks"),
 ("PoE+ switch 8-port (pharmacy)", 1, "units", f"{pharm_drops} drops + fibre uplink"),
 ("Wi-Fi 6 access points", 8, "units", "waiting hall, 300 phones"),
 ("Cat6 UTP cable (with 10% spare)", copper_total, "m", f"{drops} drops, avg lengths {copper_m:.0f} m raw"),
 ("OM4 multimode fibre, pharmacy (96 m +10%)", fibre_pharmacy, "m", "2-core"),
 ("Single-mode OS2 fibre to main building (420 m +10%)", fibre_main, "m", "2-core + 2 spare"),
 ("RJ45 Cat6 connectors/keystone jacks", drops * 2 + 20, "pcs", "both ends + 20 spare"),
 ("Cat6 patch cords 1-2 m", drops + 10, "pcs", "T568B both ends"),
 ("LC duplex connectors / pigtails", 12, "pcs", "fibre terminations"),
 ("SFP 1G/10G modules (SM/MM)", 4, "pcs", "main link + pharmacy link"),
 ("24-port patch panel Cat6", math.ceil((drops+pharm_drops)/24), "units", ""),
 ("Fibre patch panel / ODF", 1, "unit", ""),
 ("Wall-mount rack 9U with cable manager", 1, "unit", "telecom room"),
 ("UPS 1 kVA", 1, "unit", "telecom room"),
]
with open("bom_outpatient.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Item", "Qty", "Unit", "Note"]); w.writerows(rows)
for r in rows: print(f"{r[0]:<55}{r[1]:>6} {r[2]:<6} {r[3]}")
