"""Task 3.1 - check each outpatient run against TIA/EIA-568 limits."""
PERMANENT_LINK = 90   # m
CHANNEL = 100         # m (permanent link + patch cords)
RUNS = [("Consulting rooms (min)", 35), ("Consulting rooms (max)", 80),
        ("Pharmacy", 96), ("Waiting-hall APs", 60), ("Link to main building", 420)]

print(f"{'Run':<26}{'Length':>7}  Verdict / fix")
for name, d in RUNS:
    if d <= PERMANENT_LINK:
        v = "OK - Cat6 UTP within 90 m permanent link"
    elif d <= CHANNEL:
        v = "BREAKS 90 m permanent-link limit (channel 100 m only with patch cords) -> fibre or add switch/closet"
    elif d <= 550:
        v = ("BREAKS 100 m -> fibre: OM4 multimode (1G up to 550 m; 10G only ~400 m) "
             "or OS2 single-mode (10G+, 10 km)")
    else:
        v = "single-mode fibre"
    print(f"{name:<26}{d:>5} m  {v}")

print("\nMixed T568A / T568B patch cable = CROSSOVER cable (pairs 2 and 3 swapped).")
print("Modern switch ports with Auto-MDIX detect and correct it, so link still comes up;")
print("old ports without Auto-MDIX (hubs, old NICs) would NOT link PC-to-switch with it.")
