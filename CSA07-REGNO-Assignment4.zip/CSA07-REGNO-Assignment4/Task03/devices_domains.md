# Task 3.2 - Device choice and domain counts (hospital outpatient block)

| Device | Use in design | Reason |
|---|---|---|
| Hub | **Not used** | One collision domain, no security, half duplex |
| Layer-2 switch | Access (consulting rooms, pharmacy) | One collision domain per port, full duplex, VLANs, PoE |
| Layer-3 switch | Core/distribution | Inter-VLAN routing at wire speed |
| Router | Edge to WAN/ISP | NAT, WAN links to clinics |
| Wireless AP (Wi-Fi 6) | Waiting hall | 300 phones |
| Firewall | Between hospital and internet / patient-record zone | Stateful filtering |

**Counting (outpatient block, 48-port switch + 8-port switch + 8 APs):**
- Collision domains = one per switch port in use X + uplinks 2 -> every link is its own full-duplex domain, i.e. **no collisions**. (Replace with your own port count.)
- Broadcast domains = number of VLANs (router/L3 boundary): Clinical, Staff/Admin, Medical-devices, Guest/Wi-Fi, Management = **5 broadcast domains** (before: 1 flat).
