# Task 3.4 - T568B colour order and test

| Pin | T568B colour |
|---|---|
| 1 | White/Orange |
| 2 | Orange |
| 3 | White/Green |
| 4 | Blue |
| 5 | White/Blue |
| 6 | Green |
| 7 | White/Brown |
| 8 | Brown |

T568A swaps pairs 2 and 3: 1 White/Green, 2 Green, 3 White/Orange, 6 Orange.
A straight-through cable = same standard both ends; A at one end + B at the other = crossover.

Packet Tracer: place a PC and a switch, connect with *Copper Straight-Through*; PC to PC with *Copper Cross-Over*.
Test: `ping` and check link lights turn green. Put your screenshot in `screenshots/`.
