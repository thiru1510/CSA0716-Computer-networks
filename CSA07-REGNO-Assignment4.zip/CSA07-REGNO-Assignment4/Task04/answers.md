# Task 4 - Written points to copy into the report/README

**CSMA/CD vs switched vs CSMA/CA** - Switched full-duplex Ethernet has a dedicated pair per direction,
so no shared medium and no collisions: CSMA/CD is switched off. Wi-Fi is half-duplex on a shared radio
channel and a station cannot listen while sending (hidden terminal), so it uses collision *avoidance*
(CSMA/CA with ACK, RTS/CTS).

**Wi-Fi 6 features** - OFDMA splits a channel into resource units so many small frames are sent in one
transmission (less latency/overhead); MU-MIMO serves several clients simultaneously (uplink + downlink);
BSS colouring marks each AP's frames so neighbouring APs on the same channel can transmit concurrently
(spatial reuse); also TWT (battery saving), 1024-QAM.

**Bluetooth in the hospital** - Suits short-range (<10 m), low-power personal devices: wireless
stethoscope, pulse oximeter, glucometer, headsets, asset tags (BLE). Not suitable for critical
life-support telemetry (interference in 2.4 GHz, low rate, limited range, weak security) or bulk data.

**Virtual circuit identifiers** - Frame Relay: DLCI (10 bits, locally significant per link).
ATM: VPI (8/12 bits) + VCI (16 bits) in the cell header. MPLS: 20-bit label (plus EXP/TC 3 bits, S 1 bit, TTL 8 bits)
swapped at each LSR.

**MPLS vs internet VPN for 3 clinics** - Internet VPN (IPsec): cheap, quick, encrypted, but no bandwidth or
delay guarantee. MPLS: provider SLA, QoS classes (video consultation in a priority class), low jitter,
but costlier. Recommendation: MPLS (or SD-WAN with MPLS + VPN backup) if video consultations need guaranteed
delay (<150 ms one way, jitter <30 ms, loss <1 %); otherwise VPN. Accept a premium only up to the
cost of lost consultations/delays - state your own monthly figure.
