"""Task 4 - ALOHA, CSMA/CD, ATM overhead, Wi-Fi AP planning."""
import math

# 4.1 ALOHA
pure = 1 / (2 * math.e)
slotted = 1 / math.e
print(f"Pure ALOHA   max throughput S = 1/(2e) = {pure:.4f}  ({pure*100:.1f} % of channel, at G=0.5)")
print(f"Slotted ALOHA max throughput S = 1/e   = {slotted:.4f}  ({slotted*100:.1f} % of channel, at G=1)")

# CSMA/CD minimum frame size
rate, length, v = 10e6, 2500, 2e8
tprop = length / v
rtt = 2 * tprop
bits = rate * rtt
print(f"\nCSMA/CD: propagation {tprop*1e6:.1f} us, round trip {rtt*1e6:.1f} us")
print(f"  min frame = rate x 2*Tprop = {bits:.0f} bits = {bits/8:.2f} bytes (~{math.ceil(bits/8)} bytes)")
print("  (IEEE 802.3 fixes 512 bits / 64 bytes, which allows 2500 m with repeater delays)")

# 4.3 ATM vs Ethernet overhead
atm = 5 / 53
print(f"\nATM cell: header 5 / cell 53 = {atm*100:.2f} % header overhead (cell tax)")
eth_hdr = 14 + 4                       # header + FCS
for payload in (46, 512, 1500):
    print(f"Ethernet payload {payload:>4} B: overhead {eth_hdr/(payload+eth_hdr)*100:5.2f} % "
          f"(18 B); incl. preamble+IFG {(eth_hdr+20)/(payload+eth_hdr+20)*100:5.2f} %")
payload = 1500
cells = math.ceil((payload + 8) / 48)  # AAL5 8-byte trailer
atm_bytes = cells * 53
print(f"1500 B IP packet over ATM/AAL5: {cells} cells = {atm_bytes} B on wire, overhead "
      f"{(atm_bytes-payload)/atm_bytes*100:.1f} %")

# 4.2 Wi-Fi AP count
phones, per_ap = 300, 40
aps = math.ceil(phones / per_ap)
print(f"\nWi-Fi: {phones} phones / {per_ap} per AP = {aps} APs (use 5 GHz first, 2.4 GHz for legacy)")
print("2.4 GHz reuse pattern 1-6-11 ; 5 GHz 20/40 MHz non-DFS channels 36,40,44,48,149,153,157,161")
for i in range(aps):
    c24 = (1, 6, 11)[i % 3]
    c5 = (36, 40, 44, 48, 149, 153, 157, 161)[i % 8]
    print(f"  AP{i+1}: 2.4 GHz ch {c24:>2} | 5 GHz ch {c5}")
