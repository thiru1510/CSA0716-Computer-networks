# Task 5 - Tests and answers

## 802.1Q overhead
The tag adds **4 bytes** (TPID 0x8100 2 B + PCP 3 b + DEI 1 b + VID 12 b = 2 B).
Max Ethernet frame grows 1518 -> 1522 bytes (FCS recomputed). Overhead for a 1500 B payload = 4/1522 = 0.26 %.

## Ping test matrix (replace "Actual" with YOUR Packet Tracer result and add screenshots)
| From | To | Expected | Actual |
|---|---|---|---|
| Office PC | CCTV camera | Success (routed) | |
| Office PC | Guest PC | Success or blocked - your policy (ACL only restricts guest-initiated) | |
| Guest PC | Office PC | **Fail** (ACL) | |
| Guest PC | CCTV camera | **Fail** (ACL) | |
| Guest PC | Internet server 8.8.8.8 | **Success** | |
| Guest PC | Guest gateway 192.168.30.1 | Success | |
| Before routing: VLAN 30 PC -> VLAN 10 PC | **Fail** (different VLANs, no router) | |

## Broadcast domains
- Before: all ports on one VLAN -> **1** broadcast domain (+1 for the router/ISP link).
- After: VLAN 10, 20, 30 -> **3** broadcast domains (+1 for the router/ISP link).
- Collision domains: unchanged = one per switch port (full-duplex).

## Alternative: physical separation of guest Wi-Fi
| Measure | VLAN | Separate switch + ISP line |
|---|---|---|
| Equipment cost | Low (config only) | + switch, AP, firewall, extra internet line |
| Isolation | Logical (good; VLAN-hopping misconfig risk) | Complete (air-gapped) |
| Management | Central, one device set | Separate devices to patch and monitor |
Physical separation is worth it for high-security/compliance zones (e.g., payment or patient-data networks)
or when a guest line must be legally/billing independent.
