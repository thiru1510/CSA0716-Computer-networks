"""Task 6 Stage 4 - address plan from 10.0.0.0/8 and capacity check."""
import ipaddress, csv
# (building, VLAN name, VLAN id, hosts needed)  10 years growth x1.5 included
PLAN = [
 ("Academic", "Staff",   110, 300), ("Academic", "Student", 120, 1500), ("Academic", "Guest", 130, 200), ("Academic", "CCTV", 140, 120),
 ("Labs",     "Staff",   210, 40),  ("Labs",     "Student", 220, 900),  ("Labs",     "CCTV", 240, 60),
 ("Library",  "Staff",   310, 50),  ("Library",  "Student", 320, 1000), ("Library",  "Guest", 330, 200), ("Library", "CCTV", 340, 60),
 ("Hostels",  "Student", 420, 4600),("Hostels",  "Staff",   410, 100),  ("Hostels",  "CCTV", 440, 200),
 ("Auditorium","Guest", 530, 800),  ("Auditorium","Staff",  510, 60),   ("Auditorium","CCTV", 540, 80),
 ("DataCentre","Servers",610, 200), ("DataCentre","Mgmt",   699, 100),
]
base = ipaddress.ip_network("10.0.0.0/8")
cursor = int(ipaddress.ip_address("10.10.0.0"))
rows = []
print(f"{'Building':<11}{'VLAN':<9}{'ID':>4} {'Subnet':<18}{'Usable':>7}{'Need':>6}")
for b, v, vid, need in PLAN:
    bits = (need + 2).bit_length()
    prefix = 32 - bits
    size = 2 ** bits
    cursor = (cursor + size - 1) // size * size          # align
    net = ipaddress.ip_network((cursor, prefix))
    usable = net.num_addresses - 2
    assert usable >= need, (b, v)
    print(f"{b:<11}{v:<9}{vid:>4} {str(net):<18}{usable:>7}{need:>6}")
    rows.append([b, v, vid, str(net), usable, need, str(net[1])])
    cursor += size
# P2P links
p2p = ipaddress.ip_network("10.250.0.0/24")
print("\nPoint-to-point /30 links from", p2p)
for i, sub in enumerate(list(p2p.subnets(new_prefix=30))[:8]):
    print(f"  link{i+1}: {sub}")
print("Loopbacks 10.255.0.0/24 ; ISP-1 203.0.113.0/30 ; ISP-2 198.51.100.0/30 (documentation ranges)")
with open("address_plan.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Building","VLAN","VLAN ID","Subnet","Usable","Needed","Gateway"]); w.writerows(rows)
