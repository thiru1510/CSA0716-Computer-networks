"""Task 6 - users, peak traffic, uplink bandwidth and oversubscription."""
import csv, math
# name, users(peak concurrent), devices/user, wired 1G ports, Wi-Fi 6 APs, Mbps per active device, active fraction
B = [
 ("Academic block", 1500, 2.0, 400,  60, 3, 0.4),
 ("Laboratories",    600, 1.0, 660,  20, 8, 0.8),   # 600 computers + printers/CCTV
 ("Library",         800, 2.0, 150,  30, 3, 0.4),
 ("Hostels (5)",    3000, 2.5, 1500, 150, 4, 0.5),
 ("Auditorium",     1000, 1.5,  50,  40, 2, 0.5),
]
UPLINK_G = {"Academic block": 40, "Laboratories": 40, "Library": 20, "Hostels (5)": 100, "Auditorium": 20}  # Gbps (n x 10G LACP)
TARGET = 20   # access -> distribution oversubscription limit

rows, tot_peak = [], 0
print(f"{'Building':<16}{'Users':>6}{'Dev':>6}{'Peak Mbps':>10}{'Access Mbps':>13}{'Uplink':>9}{'Oversub':>9}")
for name, u, dpu, ports, aps, mbps, act in B:
    dev = u * dpu
    peak = dev * act * mbps
    access = (ports + aps) * 1000
    ratio = access / (UPLINK_G[name] * 1000)
    tot_peak += peak
    flag = "" if ratio <= TARGET else "  <-- exceeds 20:1"
    print(f"{name:<16}{u:>6}{dev:>6.0f}{peak:>10.0f}{access:>13,}{UPLINK_G[name]:>6} G{ratio:>8.1f}:1{flag}")
    rows.append([name, u, dev, round(peak), access, f"{UPLINK_G[name]}G", f"{ratio:.1f}:1"])

# Data centre: 100 servers x 10G access, 4 x 40G uplinks
dc_ratio = 100 * 10 / (4 * 40)
print(f"{'Data centre':<16}{'-':>6}{'-':>6}{'-':>10}{1_000_000:>13,}{160:>6} G{dc_ratio:>8.1f}:1  (east-west stays inside DC)")
rows.append(["Data centre", "-", "-", "-", 1_000_000, "160G", f"{dc_ratio:.1f}:1"])

# Distribution -> core (each zone dual-homed 2 x 40G to EACH of 2 cores = 160G)
zones = {"Academic+Library+Auditorium": 40 + 20 + 20, "Laboratories": 40, "Hostels": 100, "Data centre": 160}
print("\nDistribution -> core (each zone: 2x40G to each of 2 cores = 160G, only 80G usable if one core is down):")
for z, g in zones.items():
    print(f"  {z:<28} building uplinks {g:>3} G -> core 160 G : {g/160:4.2f}:1 normal, {g/80:4.2f}:1 with one core down")

demand = tot_peak / 1000
internet = demand * 0.2
isp = math.ceil(internet)
print(f"\nCampus peak ~ {demand:.1f} Gbps; assume 20 % leaves the campus -> {internet:.1f} Gbps internet peak")
print(f"Two providers, each sized {isp} Gbps (active/active, either one carries the full load after a failure)")

with open("uplink_table.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["Building", "Users", "Devices", "Peak Mbps", "Access capacity Mbps", "Uplink", "Oversub"])
    w.writerows(rows)

print("\n--- Collapsed core (alternative) ---")
core, dist_each, nz = 2, 2, 4
full, collapsed = core + nz * dist_each, nz * dist_each
COST = 1_200_000     # placeholder Rs per core chassis - replace with a real quote
print(f"3-tier: {core} core + {nz}x{dist_each} distribution = {full} chassis;  collapsed: {collapsed} -> saves {full-collapsed}")
print(f"Saving ~ Rs {(full-collapsed)*COST:,} (+ optics) at placeholder price Rs {COST:,}")
print("Collapsed: distribution switches are fully meshed; one switch failure removes its zone AND\n"
      "the inter-zone transit, and a pair failure splits the campus. 3-tier: a core failure removes 0 zones (dual-homed).")
