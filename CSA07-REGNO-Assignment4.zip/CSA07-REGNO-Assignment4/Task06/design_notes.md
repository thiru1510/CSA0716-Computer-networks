# Task 6 - Design summary (copy figures into your report)

**Stage 1 requirements (testable):** e.g. R1 every building reachable at >= 1 Gbps wired / >= 100 Mbps Wi-Fi per active user;
R2 single link or single core failure recovers in < 5 s; R3 Guest cannot reach Staff/Student/CCTV (ping fails);
R4 internet stays up if one ISP fails; R5 uplink oversubscription <= 20:1 (access->distribution), <= 4:1 (distribution->core);
R6 addressing leaves >= 50 % free for 10 years. See `output_design_calc.txt` for user/traffic estimates.

**Stage 2 topology:** Core = 2 switches linked to each other (mesh of 2) ; Distribution = 2 per zone (Academic/Library/Auditorium,
Labs, Hostels, Data centre) each dual-homed to both cores (partial mesh); Access = star inside each building.

**Stage 3 decisions:** Layer-3 core/distribution (40G), 1G PoE+ access, single-mode OS2 fibre between buildings (40 acres),
Cat6A inside buildings, Wi-Fi 6 with BSS colouring, VLANs Staff/Student/Guest/CCTV/Servers/Mgmt, OSPF, two ISPs (BGP or floating static), firewall pair at the edge, NAT.

**Stage 4:** `address_plan.csv`, `uplink_table.csv`, bill of materials (create from your price quotes), diagrams in report.

**Alternative - collapsed core:** see bottom of `output_design_calc.txt`. Decision template: saving Rs 24 lakh vs risk of campus-wide outage of
a 6,000-user campus over 10 years -> keep three tiers for the data centre/hostel zones, collapse only for a small phase 1 if budget forces.
