# Task 6 Stage 5 - Demonstration checklist (take a screenshot of each)
1. Connectivity: Student PC -> Lab PC, Staff PC -> server, any PC -> 8.8.8.8 (ISP).
2. VLAN separation: Guest PC cannot ping Staff/Student/CCTV (expected "Destination unreachable"), can ping internet.
3. `show ip route`, `show ip ospf neighbor`, `show vlan brief`, `show interfaces trunk`.
4. Core-link failure: ping -t from a PC; shut `interface Gi0/3` on CORE1 (or delete the link) and show the ping recovering via CORE2.
5. ISP failure: shut Gi0/2 on CORE1; internet reachable via ISP2 (floating static route takes over).
6. Save the `.pkt` as Task06/campus_network.pkt and `show running-config` of each device into Task06/configs/.
